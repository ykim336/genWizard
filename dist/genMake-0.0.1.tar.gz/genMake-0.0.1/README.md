# genMake
 a powerful openAI template that enables anyone to manage this amazing tool
